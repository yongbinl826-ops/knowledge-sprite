"""Offline audit-helper checks; synthetic evidence is never used by live cases."""
from backend.app.extractor import MetadataExtractor
from scripts.live_acceptance_revision import audit_resource_evidence


def extracted_item(kind="VideoObject"):
    html = '''<script type="application/ld+json">{
      "@type": "%s", "name": "Synthetic lesson", "hasPart": [
        {"@type": "Clip", "name": "Synthetic chapter", "url": "https://example.org/lesson#chapter", "startOffset": 65}
      ]
    }</script>''' % kind
    metadata = MetadataExtractor().extract(html, "https://example.org/lesson", "2026-10-13T00:00:00Z")
    evidence = metadata.pop("evidence")
    return {"resource": {"resource_id": "fixture-only", "url": "https://example.org/lesson", **metadata}, "evidence": evidence}


def test_plain_course_and_directory_do_not_verify_video():
    audit = audit_resource_evidence(extracted_item("Course"))
    assert audit["has_type_provenance"]
    assert not audit["page_verified"] and not audit["video_catalog"]


def test_actual_video_structure_and_per_chapter_evidence_are_required():
    item = extracted_item()
    audit = audit_resource_evidence(item)
    assert audit["page_verified"] and audit["video_catalog"]
    assert audit["verified_chapter_count"] == 1
    assert not audit["playback_verified"]
    item["resource"]["chapters"][0]["start_seconds"] = 999
    assert not audit_resource_evidence(item)["video_catalog"]


def test_page_flag_and_type_provenance_cannot_replace_video_evidence():
    item = extracted_item()
    item["resource"]["field_provenance"].pop("video_evidence_status")
    assert not audit_resource_evidence(item)["page_verified"]
    item["resource"]["field_provenance"]["video_evidence_status"] = item["resource"]["field_provenance"]["resource_type"]
    assert not audit_resource_evidence(item)["page_verified"]


def test_search_video_discovery_does_not_verify_page_or_playback():
    item = {"resource": {"resource_type": "video", "url": "https://example.org/video", "video_evidence_status": "search_discovered",
        "metadata_evidence_level": "page", "fetch_status": "fetched", "chapters": [],
        "field_provenance": {"video_evidence_status": {"evidence_id": "search-fixture", "source": "search_template"}, "resource_type": {"evidence_id": "search-fixture"}}},
        "evidence": [{"evidence_id": "search-fixture", "kind": "search", "type_source": "search_template", "resource_type_hint": "video", "url": "https://example.org/video"}]}
    audit = audit_resource_evidence(item)
    assert audit["search_discovered"] and not audit["page_verified"] and not audit["video_catalog"]
    item["resource"]["playback_verified"] = True
    audit = audit_resource_evidence(item)
    assert audit["playback_claimed"] and not audit["playback_verified"]
    item["evidence"][0]["resource_type_hint"] = "unknown"
    assert not audit_resource_evidence(item)["search_discovered"]


def test_course_search_entry_is_valid_discovery_but_not_video_verification():
    url = "https://www.icourse163.org/course/TEST-123456"
    item = {"resource": {"resource_type": "course", "url": url, "video_evidence_status": "none",
        "metadata_evidence_level": "search", "fetch_status": "not_fetched", "chapters": [],
        "field_provenance": {"resource_type": {"evidence_id": "search-course", "source": "url_pattern", "url": url}}},
        "evidence": [{"evidence_id": "search-course", "kind": "search", "url": url}]}
    audit = audit_resource_evidence(item)
    assert audit["course_search_candidate"] and audit["has_type_provenance"]
    assert not any(audit[field] for field in ("search_discovered", "page_verified", "video_catalog", "playback_verified"))
    item["resource"]["field_provenance"]["resource_type"] = {"source": "jsonld.@type", "evidence_id": "page-course"}
    item["evidence"].append({"evidence_id": "page-course", "kind": "page", "field": "resource_type", "url": url})
    assert audit_resource_evidence(item)["course_search_candidate"]
    assert not audit_resource_evidence(extracted_item("Course"))["course_search_candidate"]
