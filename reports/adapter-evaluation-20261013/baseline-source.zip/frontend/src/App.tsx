import { BookIcon } from './components/Icons';
import { SearchForm } from './components/SearchForm';
import { ResultsPanel } from './components/ResultsPanel';
import { CapabilitiesFooter } from './components/CapabilitiesFooter';
import { useSearch } from './useSearch';

export default function App() {
  const search = useSearch();
  return <><a className="skip-link" href="#knowledge">跳转到知识点输入</a><header className="site-header"><div className="brand"><BookIcon/><span>项目制知识引导小精灵</span></div><span className="header-description">课程与视频发现</span></header>
    <main><div className="intro"><h1>从知识点，找到学习入口</h1><p>输入你想学的知识点，发现公开课程与视频，回到原平台继续学习。</p></div><div className="workspace"><SearchForm busy={search.busy} maxPoints={search.capabilities?.limits.max_knowledge_points || 5} onSubmit={search.submit}/><ResultsPanel capabilities={search.capabilities} capabilityError={search.capabilityError} job={search.job} results={search.results} jobId={search.jobId} error={search.error} onRetry={search.retryPoll} onRefresh={() => void search.refreshCapabilities()}/></div><CapabilitiesFooter capabilities={search.capabilities} onRefresh={() => void search.refreshCapabilities()}/></main></>;
}
