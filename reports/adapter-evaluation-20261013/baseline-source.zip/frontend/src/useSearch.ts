import { useCallback, useEffect, useRef, useState } from 'react';
import { api } from './api';
import type { Capabilities, SearchJob, SearchRequest, SearchResults } from './types';

const terminal = new Set(['completed', 'partial', 'failed', 'interrupted']);
export function useSearch() {
  const [capabilities, setCapabilities] = useState<Capabilities | null>(null);
  const [capabilityError, setCapabilityError] = useState('');
  const [jobId, setJobId] = useState(() => new URLSearchParams(location.search).get('job') || '');
  const [job, setJob] = useState<SearchJob | null>(null);
  const [results, setResults] = useState<SearchResults | null>(null);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [pollRevision, setPollRevision] = useState(0);
  const submissionLock = useRef(false);
  const refreshCapabilities = useCallback(async () => {
    try { setCapabilities(await api<Capabilities>('/api/capabilities')); setCapabilityError(''); }
    catch (err) { setCapabilityError((err as Error).message); }
  }, []);

  useEffect(() => { void refreshCapabilities(); }, [refreshCapabilities]);
  useEffect(() => {
    if (!jobId) return;
    const controller = new AbortController();
    let timer = 0;
    let failures = 0;
    const poll = async () => {
      try {
        const [nextJob, nextResults] = await Promise.all([
          api<SearchJob>(`/api/search-jobs/${encodeURIComponent(jobId)}`, { signal: controller.signal }),
          api<SearchResults>(`/api/search-jobs/${encodeURIComponent(jobId)}/results`, { signal: controller.signal }),
        ]);
        if (controller.signal.aborted) return;
        // A job may finish between these two reads. Fetch once more for a coherent terminal snapshot.
        const coherentResults = terminal.has(nextJob.status) && nextResults.status !== nextJob.status
          ? await api<SearchResults>(`/api/search-jobs/${encodeURIComponent(jobId)}/results`, { signal: controller.signal })
          : nextResults;
        if (controller.signal.aborted) return;
        setJob(nextJob); setResults(coherentResults); setError(''); failures = 0;
        if (terminal.has(nextJob.status)) { void refreshCapabilities(); return; }
      } catch (err) {
        if (controller.signal.aborted) return;
        failures += 1;
        setError(`进度暂时无法读取：${(err as Error).message}${failures < 3 ? ' 正在重试。' : ' 已暂停轮询，可手动重试。'}`);
        if (failures >= 3) return;
      }
      timer = window.setTimeout(poll, 1500);
    };
    void poll();
    return () => { controller.abort(); window.clearTimeout(timer); };
  }, [jobId, pollRevision, refreshCapabilities]);

  const submit = async (request: SearchRequest) => {
    if (submissionLock.current) return;
    submissionLock.current = true;
    setSubmitting(true); setError('');
    try {
      const created = await api<{ job_id: string }>('/api/search-jobs', { method: 'POST', body: JSON.stringify(request) });
      setJob(null); setResults(null); setJobId(created.job_id);
      const url = new URL(location.href); url.searchParams.set('job', created.job_id);
      history.replaceState(null, '', url);
    } catch (err) { setError((err as Error).message); }
    finally { submissionLock.current = false; setSubmitting(false); }
  };
  return { capabilities, capabilityError, jobId, job, results, error, submitting, submit,
    busy: submitting || (!!jobId && !job && !error) || (!!job && !terminal.has(job.status)),
    refreshCapabilities, retryPoll: () => setPollRevision(value => value + 1) };
}
