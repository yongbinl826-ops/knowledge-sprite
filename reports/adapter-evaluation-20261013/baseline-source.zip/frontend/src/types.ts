export type Platform = 'bilibili' | 'icourse163' | 'xuetangx';
export type JobStatus = 'queued' | 'running' | 'completed' | 'partial' | 'failed' | 'interrupted';
export type SearchRequest = {
  knowledge_points: string[];
  student_level: 'beginner' | 'intermediate' | 'advanced' | 'any';
  language: 'zh' | 'en' | 'any';
  project_context: string;
  technical_version: string;
  preferred_platforms: Platform[];
};
export type Capability = { status: string; message: string };
export type Capabilities = {
  mode: string;
  search: Capability & { selected_provider: string; providers: (Capability & { name: string })[] };
  llm: Capability;
  fetch: Capability & { browser_fallback: boolean };
  platforms: { id: string; name: string; discovery: string; metadata: string; playback: string }[];
  limits: { max_knowledge_points: number; max_results_per_point: number; max_search_requests: number; max_detail_pages: number };
};
export type SearchJob = {
  job_id: string; status: JobStatus; phase: string;
  created_at: string; updated_at: string; request: SearchRequest;
  progress: { queries_planned: number; queries_completed: number; search_requests: number; search_successes: number; search_failures: number; candidates_discovered: number; resources_discovered: number; details_attempted: number; details_completed: number; details_cached?: number; catalog_pages_attempted?: number; catalog_pages_completed?: number; cache_hits: number };
  budgets: { max_search_requests: number; max_detail_pages: number; deadline_seconds: number };
  warnings: string[]; errors: { code: string; message: string }[];
  knowledge_points: { knowledge_point_id: string; text: string }[];
};
export type CacheInfo = { hit: boolean; cached_at: string | null; stale: boolean };
export type FieldProvenance = { evidence_id?: string; source?: string; url?: string; fetched_at?: string };
export type Chapter = {
  title: string; url?: string | null; evidence_id?: string; source?: string;
  start_seconds?: number | null; end_seconds?: number | null;
  field_provenance?: Record<string, FieldProvenance>;
};
export type Resource = {
  resource_id: string; title: string; url: string; canonical_url: string;
  platform: string; resource_type: string;
  author: string | null; description: string | null; language: string | null;
  duration_seconds: number | null; published_at: string | null; discovered_at: string; fetched_at: string | null;
  fetch_status: string; metadata_evidence_level: string;
  video_evidence_status?: 'search_discovered' | 'page_verified' | 'none';
  requires_login: boolean | null; requires_payment: boolean | null; requires_enrollment: boolean | null;
  chapters: Chapter[]; catalog_kind?: 'course_outline' | 'video_playlist' | 'video_chapters' | null; catalog_fetch_status?: string | null; field_provenance: Record<string, unknown>;
  cache?: CacheInfo; playback_verified: boolean;
};
export type Evidence = {
  evidence_id: string; kind: string; source: string; query?: string;
  url: string; title?: string; snippet?: string; text?: string; field?: string;
  observed_at?: string; fetched_at?: string; reviewed_at?: string; cache?: CacheInfo;
};
export type ResourceItem = {
  resource: Resource;
  match: { knowledge_point_id: string; resource_id: string; ranking_score: number; recommendation_reason: string; matched_evidence_ids: string[]; coverage_basis: string[] };
  evidence: Evidence[];
};
export type SearchResults = {
  job_id: string; status: JobStatus;
  groups: { knowledge_point_id: string; text: string; total_matches: number; items: ResourceItem[]; platform_items?: Record<string, ResourceItem[]> }[];
  warnings: string[];
  search_attempts: { knowledge_point_id: string; query: string; provider: string; status: string; candidate_count: number; cached_at: string | null; cache_hit: boolean; stale: boolean; error_code?: string }[];
};
