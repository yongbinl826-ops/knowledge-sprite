import { test, expect, type Page } from '@playwright/test';
import type { Capabilities, Chapter, Evidence, SearchJob, SearchResults, ResourceItem } from '../src/types';

// These isolated transport fixtures are tests only. The production app has no fixture or demo import.
const time = '2026-10-13T07:00:00Z';
const caps: Capabilities = {
  mode: 'live', search: { selected_provider: 'searxng', status: 'configured', message: '已配置，待验证', providers: [{ name: 'searxng', status: 'configured', message: '参数已配置' }] },
  llm: { status: 'unconfigured', message: '使用规则查询与规则排序' }, fetch: { status: 'available', message: '仅采集允许访问的公开页面', browser_fallback: false },
  platforms: [], limits: { max_knowledge_points: 5, max_results_per_point: 5, max_search_requests: 30, max_detail_pages: 40 },
};
const baseJob: SearchJob = {
  job_id: 'test-job', status: 'completed', phase: 'done', created_at: time, updated_at: time,
  request: { knowledge_points: ['非预设知识点：空间哈希', '边界条件'], student_level: 'beginner', language: 'zh', technical_version: '', project_context: '', preferred_platforms: ['bilibili'] },
  progress: { queries_planned: 4, queries_completed: 4, search_requests: 4, search_successes: 4, search_failures: 0, candidates_discovered: 2, resources_discovered: 2, details_attempted: 2, details_completed: 1, cache_hits: 1 },
  budgets: { max_search_requests: 30, max_detail_pages: 40, deadline_seconds: 180 }, warnings: [], errors: [],
  knowledge_points: [{ knowledge_point_id: 'kp1', text: '非预设知识点：空间哈希' }, { knowledge_point_id: 'kp2', text: '边界条件' }],
};
const item: ResourceItem = {
  resource: { resource_id: 'r1', title: '测试响应：空间哈希 <img src=x onerror=alert(1)>', url: 'https://www.bilibili.com/video/BV_TEST_ONLY?p=2', canonical_url: 'https://www.bilibili.com/video/BV_TEST_ONLY?p=2', platform: 'bilibili', resource_type: 'video', author: null, description: null, language: null, duration_seconds: null, published_at: null, discovered_at: time, fetched_at: null, fetch_status: 'robots_blocked', metadata_evidence_level: 'search', requires_login: null, requires_payment: null, requires_enrollment: null, chapters: [], field_provenance: { title: { evidence_id: 'e1', source: 'search' } }, cache: { hit: true, cached_at: time, stale: true }, playback_verified: false },
  match: { knowledge_point_id: 'kp1', resource_id: 'r1', ranking_score: 0.73, recommendation_reason: '根据标题与摘要匹配，可能涉及空间哈希。', matched_evidence_ids: ['e1'], coverage_basis: ['title', 'snippet'] },
  evidence: [{ evidence_id: 'e1', kind: 'search', source: 'searxng', query: '空间哈希 教程', url: 'https://www.bilibili.com/video/BV_TEST_ONLY?p=2', snippet: '测试摘要，仅用于自动化测试。', observed_at: time }],
};
const otherItem: ResourceItem = { ...item, resource: { ...item.resource, resource_id: 'r2', title: '测试响应：公开教程页面', url: 'https://example.org/tutorial?chapter=2', platform: 'other', fetch_status: 'fetched', metadata_evidence_level: 'page', fetched_at: time, cache: { hit: false, cached_at: null, stale: false } }, match: { ...item.match, resource_id: 'r2' } };
const results: SearchResults = {
  job_id: 'test-job', status: 'completed', warnings: [],
  groups: [{ knowledge_point_id: 'kp1', text: '非预设知识点：空间哈希', total_matches: 2, items: [item, otherItem] }, { knowledge_point_id: 'kp2', text: '边界条件', total_matches: 1, items: [item] }],
  search_attempts: [{ knowledge_point_id: 'kp1', query: '空间哈希 教程', provider: 'searxng', status: 'success', candidate_count: 2, cached_at: null, cache_hit: false, stale: false }],
};
const diagnostics = new WeakMap<Page, { runtime: string[]; console: string[]; blocked: string[] }>();
test.beforeEach(async ({ page }) => {
  const log = { runtime: [] as string[], console: [] as string[], blocked: [] as string[] };
  diagnostics.set(page, log);
  page.on('pageerror', error => log.runtime.push(error.message));
  page.on('console', message => { if (['warning', 'error'].includes(message.type())) log.console.push(message.text()); });
  // Default deny every API and external HTTP request. Specific fixtures added
  // later override this route, so no test can fall through to the real backend.
  await page.route('**/*', route => {
    const url = new URL(route.request().url());
    if (url.origin === 'http://127.0.0.1:5173' && !url.pathname.startsWith('/api/')) return route.continue();
    log.blocked.push(url.href);
    return route.abort('blockedbyclient');
  });
});
test.afterEach(async ({ page }, testInfo) => {
  const log = diagnostics.get(page)!;
  await testInfo.attach('browser-diagnostics', { body: JSON.stringify(log, null, 2), contentType: 'application/json' });
  expect(log.runtime).toEqual([]);
  expect(log.blocked).toEqual([]);
});
async function setup(page: Page, capability = caps, job = baseJob, resourceResults = results) {
  await page.route('**/api/capabilities', route => route.fulfill({ json: capability }));
  await page.route('**/api/search-jobs', route => route.fulfill({ status: 202, json: { job_id: 'test-job', status: 'queued' } }));
  await page.route('**/api/search-jobs/test-job', route => route.fulfill({ json: job }));
  await page.route('**/api/search-jobs/test-job/results', route => route.fulfill({ json: resourceResults }));
}

function chapterEvidence(chapter: Chapter, index: number): Evidence {
  return { evidence_id: chapter.evidence_id || `fixture-chapter-${index}`, kind: 'catalog', field: `chapters.${index}`,
    source: 'fixture.explicit_chapter', url: 'https://example.org/course', fetched_at: time,
    text: JSON.stringify(Object.fromEntries(['title', 'url', 'start_seconds', 'end_seconds', 'duration_seconds'].map(key => [key, chapter[key as keyof Chapter] ?? null]))) };
}

test('平台筛选能显示全平台前五名之外的课程', async ({ page }) => {
  const mooc: ResourceItem = { ...item, resource: { ...item.resource, resource_id: 'fixture-mooc', title: '测试：第六名 MOOC 课程', url: 'https://www.icourse163.org/course/TEST-123456', platform: 'icourse163', resource_type: 'course' } };
  const topFive = Array.from({ length: 5 }, (_, i) => ({ ...item, resource: { ...item.resource, resource_id: `fixture-${i}` } }));
  await setup(page, caps, baseJob, { ...results, groups: [{ ...results.groups[0], total_matches: 6, items: topFive, platform_items: { bilibili: topFive, icourse163: [mooc] } }] });
  await page.goto('/?job=test-job');
  await expect(page.locator('.resource-card')).toHaveCount(5);
  await expect(page.getByRole('heading', { name: '测试：第六名 MOOC 课程', exact: true })).toHaveCount(0);
  await page.getByLabel('来源平台').selectOption('icourse163');
  await expect(page.locator('.resource-card')).toHaveCount(1);
  await expect(page.getByRole('heading', { name: '测试：第六名 MOOC 课程', exact: true })).toBeVisible();
  await page.getByLabel('来源平台').selectOption('all');
  await expect(page.locator('.resource-card')).toHaveCount(5);
});

test('未配置状态、必填和知识点预算校验；无假结果', async ({ page }, testInfo) => {
  const consoleErrors: string[] = [];
  page.on('pageerror', error => consoleErrors.push(error.message));
  await setup(page, { ...caps, search: { ...caps.search, status: 'unconfigured', message: '请先在服务端接入 SearXNG，或启用已配置的 Tavily。' } });
  await page.goto('/');
  await expect(page).toHaveTitle('项目制知识引导小精灵 · 课程与视频发现');
  await expect(page.getByText('搜索服务尚未配置')).toBeVisible();
  await expect(page.locator('.resource-card')).toHaveCount(0);
  await expect(page.locator('vite-error-overlay')).toHaveCount(0);
  await page.screenshot({ path: testInfo.outputPath('desktop-empty.png'), fullPage: true });
  await page.getByRole('button', { name: '开始查找' }).click();
  await expect(page.getByRole('alert')).toHaveText('请至少输入一个知识点。');
  await page.getByLabel('知识点', { exact: true }).fill('一\n二\n三\n四\n五\n六');
  await page.getByRole('button', { name: '开始查找' }).click();
  await expect(page.getByRole('alert')).toHaveText('最多输入 5 个知识点，请分批查找。');
  expect(consoleErrors).toEqual([]);
});

test('多知识点提交、真实计数、分组/筛选、来源、未知、过期缓存与安全外链', async ({ page }, testInfo) => {
  await setup(page);
  let submitted: unknown;
  await page.route('**/api/search-jobs', async route => { submitted = route.request().postDataJSON(); await route.fulfill({ status: 202, json: { job_id: 'test-job' } }); });
  let pollCount = 0;
  await page.route('**/api/search-jobs/test-job', route => {
    pollCount += 1;
    return route.fulfill({ json: pollCount === 1 ? { ...baseJob, status: 'running', phase: 'searching', progress: { ...baseJob.progress, queries_completed: 1 } } : baseJob });
  });
  await page.goto('/');
  await page.getByLabel('知识点', { exact: true }).fill('非预设知识点：空间哈希\n边界条件\n边界条件');
  await page.getByLabel('技术版本').fill('WebGL 2');
  await page.getByLabel('项目背景').fill('地图可视化');
  await page.getByRole('button', { name: '开始查找' }).click();
  await expect(page.getByText('正在查找', { exact: true })).toBeVisible();
  await expect(page.locator('.progress-counts')).toContainText('1 / 4');
  await expect(page.getByText('检索完成', { exact: true })).toBeVisible();
  expect(submitted).toMatchObject({ knowledge_points: ['非预设知识点：空间哈希', '边界条件'], technical_version: 'WebGL 2', project_context: '地图可视化' });
  await expect(page.locator('.result-group')).toHaveCount(2);
  await expect(page.locator('.resource-card')).toHaveCount(3);
  await expect(page.locator('.resource-card img')).toHaveCount(0);
  await expect(page.locator('.access-line').first()).toContainText('付费：未知');
  await expect(page.locator('.cache-note').first()).toContainText('使用过期缓存');
  await expect(page.locator('.verification-note').first()).toContainText('仅搜索发现，页面详情未核验');
  await expect(page.getByRole('link', { name: '前往原平台' }).first()).toHaveAttribute('href', 'https://www.bilibili.com/video/BV_TEST_ONLY?p=2');
  await expect(page.getByRole('link', { name: '前往原平台' }).first()).toHaveAttribute('rel', 'noopener noreferrer');
  await expect(page.getByRole('link', { name: '前往原平台' }).first()).toHaveAttribute('target', '_blank');
  await expect(page.locator('.resource-card').first()).toContainText('目录暂未取得，可直接前往原平台查看。');
  await expect(page.locator('.access-line').first()).not.toContainText('可播放性');
  await page.getByLabel('来源平台').selectOption('other');
  await expect(page.locator('.resource-card')).toHaveCount(1);
  await expect(page.getByText('当前筛选下暂无匹配资源，可切换到“全部平台”和“全部类型”。')).toBeVisible();
  await page.getByLabel('来源平台').selectOption('all');
  await page.locator('.evidence-details summary').first().click();
  await expect(page.getByText('暂无可获取的目录证据，不代表来源没有目录。').first()).toBeVisible();
  await expect(page.getByText('（不是正确概率）', { exact: false }).first()).toBeVisible();
  await page.screenshot({ path: testInfo.outputPath('desktop-fixture-results.png'), fullPage: true });
});

test('正常无结果区别于服务失败', async ({ page }) => {
  await setup(page, caps, baseJob, { ...results, groups: [{ ...results.groups[0], total_matches: 0, items: [] }] });
  await page.goto('/?job=test-job');
  await expect(page.getByText('本次检索未找到符合条件的课程。可以调整知识点或语言后再试。')).toBeVisible();
  await expect(page.getByText('本次检索未能完成')).toHaveCount(0);
});

test('全部服务失败不会降级为预设课程', async ({ page }) => {
  await setup(page, caps, { ...baseJob, status: 'failed', errors: [{ code: 'configuration_error', message: '搜索服务未配置' }] }, { ...results, status: 'failed', groups: [{ ...results.groups[0], total_matches: 0, items: [] }], search_attempts: [] });
  await page.goto('/?job=test-job');
  await expect(page.getByText('本次检索未能完成')).toBeVisible();
  await expect(page.getByText('搜索服务未成功返回结果，不能判断是否存在合适课程。')).toBeVisible();
  await expect(page.locator('.resource-card')).toHaveCount(0);
  await page.getByText('搜索范围与异常记录（1）').click();
  await expect(page.getByText('configuration_error')).toBeVisible();
});

test('部分失败保留结果、任务中断如实显示', async ({ page }) => {
  await setup(page, caps, { ...baseJob, status: 'partial', warnings: ['详情预算已达到限制'], errors: [{ code: 'search_unavailable', message: '一个搜索请求失败' }] }, { ...results, status: 'partial' });
  await page.goto('/?job=test-job');
  await expect(page.getByText('部分搜索或信息补全未完成')).toBeVisible();
  await expect(page.locator('.resource-card')).toHaveCount(3);
  await page.route('**/api/search-jobs/test-job', route => route.fulfill({ json: { ...baseJob, status: 'interrupted' } }));
  await page.reload();
  await expect(page.getByText('服务重启中断了该任务。已保存的结果仍可查看，请重新提交学习需求以再次执行。')).toBeVisible();
  await expect(page.getByRole('button', { name: '开始查找' })).toBeEnabled();
});

test('移动端无横向溢出，表单可用', async ({ page }, testInfo) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await setup(page, { ...caps, search: { ...caps.search, status: 'unconfigured', message: '请先在服务端接入 SearXNG，或启用已配置的 Tavily。' } });
  await page.goto('/');
  await expect(page.getByRole('heading', { name: '从知识点，找到学习入口' })).toBeVisible();
  await page.getByLabel('知识点', { exact: true }).fill('任意新知识点');
  await page.getByLabel('学习语言').selectOption('en');
  await expect(page.getByLabel('学习语言')).toHaveValue('en');
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  await page.screenshot({ path: testInfo.outputPath('mobile-empty.png'), fullPage: true });
});

test('请求出错明确显示错误', async ({ page }) => {
  await setup(page);
  await page.route('**/api/search-jobs', route => route.fulfill({ status: 503, json: { detail: '当前搜索服务不可用' } }));
  await page.goto('/');
  await page.getByLabel('知识点', { exact: true }).fill('任意新知识点');
  await page.getByRole('button', { name: '开始查找' }).click();
  await expect(page.getByRole('alert')).toContainText('当前搜索服务不可用');
  await expect(page.locator('.resource-card')).toHaveCount(0);
  await expect(page.getByRole('button', { name: '开始查找' })).toBeEnabled();
});

test('部分页面证据与详情受阻分别标注，故障状态不隐藏', async ({ page }) => {
  const partialPageItem: ResourceItem = { ...otherItem, resource: { ...otherItem.resource, fetch_status: 'javascript_required' } };
  const failedFetchItem: ResourceItem = { ...item, resource: { ...item.resource, fetch_status: 'fetch_error' } };
  await setup(page, caps, baseJob, { ...results, groups: [{ ...results.groups[0], items: [partialPageItem, failedFetchItem] }] });
  await page.goto('/?job=test-job');
  const firstCard = page.locator('.resource-card').first();
  await expect(firstCard.locator('.evidence-label')).toHaveText('页面元信息');
  await expect(firstCard.locator('.verification-note')).toContainText('已获取部分页面信息，内容详情尚未核验');
  await expect(firstCard.locator('.verification-note')).toContainText('页面需要 JavaScript');
  await expect(firstCard.locator('.verification-note')).not.toContainText('仅搜索发现');
  await expect(page.locator('.resource-card').nth(1).locator('.verification-note')).toContainText('页面采集失败');
});

test('隔离目录fixture：章节直链、来源、时间证据与注入防护', async ({ page }, testInfo) => {
  const errors: string[] = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('console', message => { if (['warning', 'error'].includes(message.type())) errors.push(message.text()); });
  const chapters: Chapter[] = [
    { title: '第一章：坐标转换', url: 'https://example.org/tutorial?chapter=1', evidence_id: 'c1', source: 'jsonld.hasPart', start_seconds: 65, duration_seconds: 2743 },
    { title: '<img src=x onerror=alert(1)>', url: null, evidence_id: 'c2' },
    { title: '时间未知的章节', url: null, evidence_id: 'c3', start_seconds: null, end_seconds: null, duration_seconds: null },
    { title: '非法直链不展示', url: 'javascript:alert(1)', evidence_id: 'c4', start_seconds: 120, duration_seconds: 4321 },
    { title: '只有汇总证据的章节', url: null, start_seconds: 480 },
  ];
  const catalogItem: ResourceItem = {
    ...otherItem,
    resource: { ...otherItem.resource, title: '测试目录 fixture：不代表真实网站验收', resource_type: 'course', metadata_evidence_level: 'catalog', chapters,
      field_provenance: { chapters: { evidence_id: 'catalog-all', source: 'jsonld.hasPart' } } },
    evidence: [
      { evidence_id: 'catalog-all', kind: 'catalog', field: 'chapters', source: 'jsonld.hasPart', url: 'https://example.org/course', fetched_at: time },
      ...chapters.slice(0, 4).map(chapterEvidence),
    ],
  };
  await setup(page, caps, baseJob, { ...results, groups: [{ ...results.groups[0], items: [catalogItem] }] });
  await page.goto('/?job=test-job');
  await expect(page).toHaveTitle('项目制知识引导小精灵 · 课程与视频发现');
  await expect(page.locator('.evidence-label')).toHaveText('目录证据（3 项）');
  await expect(page.locator('.access-line')).toContainText('登录：');
  await page.locator('.evidence-details summary').click();
  await expect(page.locator('.chapter-list li')).toHaveCount(3);
  await expect(page.locator('.chapter-list').getByRole('link', { name: '第一章：坐标转换' })).toHaveAttribute('href', 'https://example.org/tutorial?chapter=1');
  await expect(page.locator('.chapter-list').getByRole('link', { name: '查看目录来源' }).first()).toHaveAttribute('href', 'https://example.org/course');
  await expect(page.locator('.chapter-list').getByRole('link', { name: '查看目录来源' }).first()).toHaveAttribute('rel', 'noopener noreferrer');
  await expect(page.locator('.chapter-list')).toContainText('起始时间 1:05');
  await expect(page.locator('.chapter-list')).toContainText('时长 45:43');
  await expect(page.locator('.chapter-list')).not.toContainText('时长 72:01');
  await expect(page.locator('.chapter-list')).not.toContainText('起始时间 45:43');
  await expect(page.locator('.chapter-list')).not.toContainText('起始时间 2:00');
  await expect(page.locator('.chapter-list')).not.toContainText('8:00');
  await expect(page.locator('.chapter-list li').nth(1)).toContainText('<img src=x onerror=alert(1)>');
  await expect(page.locator('.chapter-list img, .chapter-list a[href^="javascript:"]')).toHaveCount(0);
  await expect(page.locator('.chapter-list li').nth(2)).toContainText('章节直链未知');
  await expect(page.locator('vite-error-overlay')).toHaveCount(0);
  await page.screenshot({ path: testInfo.outputPath('catalog-fixture-desktop.png'), fullPage: true });
  await page.setViewportSize({ width: 390, height: 844 });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  await page.screenshot({ path: testInfo.outputPath('catalog-fixture-mobile.png'), fullPage: true });
  expect(errors).toEqual([]);
});

test('目录逐行身份和数值校验拒绝交叉引用、篡改与非法时长', async ({ page }) => {
  const chapters: Chapter[] = [
    { title: '有效未知字段章节', evidence_id: 'strict-0', url: null, start_seconds: null, end_seconds: null, duration_seconds: null },
    { title: '有效零起点章节', evidence_id: 'strict-1', start_seconds: 0, end_seconds: 0, duration_seconds: 1 },
  ];
  const records = chapters.map(chapterEvidence);
  // Missing and explicit null are equivalent unknowns in either direction.
  records[0].text = JSON.stringify({ title: chapters[0].title });
  const add = (values: Record<string, unknown>) => {
    const index = chapters.length;
    const chapter = { title: `不应验证的章节 ${index}`, url: null, evidence_id: `strict-${index}`, ...values } as unknown as Chapter;
    chapters.push(chapter);
    const record = chapterEvidence(chapter, index);
    records.push(record);
    return { chapter, record };
  };
  // Identical facts with another row's ID still cannot certify this index.
  add({ title: chapters[0].title, url: null, start_seconds: null, end_seconds: null, duration_seconds: null }).chapter.evidence_id = chapters[0].evidence_id;
  for (const [field, value] of Object.entries({ title: '篡改后的标题', url: 'https://example.org/tampered', start_seconds: 10, end_seconds: 10, duration_seconds: 10 })) {
    const { chapter } = add({});
    Object.assign(chapter, { [field]: value });
  }
  for (const duration of [true, false, '12', -1, 0, '__INFINITE_SECONDS__']) {
    const { record } = add({ duration_seconds: duration });
    if (duration === '__INFINITE_SECONDS__') record.text = record.text!.replace('"__INFINITE_SECONDS__"', '1e309');
  }
  for (const offsets of [{ start_seconds: true }, { end_seconds: '1' }, { start_seconds: -1 }, { start_seconds: 2, end_seconds: 1 }]) add(offsets);
  add({}).record.field = 'chapters.999';
  add({}).record.text = undefined;
  add({}).record.text = '[]';
  add({}).record.url = 'https://user:secret@example.org/course';
  add({}).record.url = 'javascript:alert(1)';
  add({ url: 'javascript:alert(1)' });
  const catalogItem: ResourceItem = { ...otherItem,
    resource: { ...otherItem.resource, metadata_evidence_level: 'catalog', chapters }, evidence: records };
  const strictResults: SearchResults = { ...results, groups: [{ ...results.groups[0], items: [catalogItem] }] };
  await setup(page, caps, baseJob, strictResults);
  // JSON number overflow is legal JSON but becomes Infinity in the browser.
  const body = JSON.stringify(strictResults).replaceAll('"__INFINITE_SECONDS__"', '1e309');
  await page.route('**/api/search-jobs/test-job/results', route => route.fulfill({ contentType: 'application/json', body }));
  await page.goto('/?job=test-job');
  await expect(page.locator('.evidence-label')).toHaveText('目录证据（2 项）');
  await page.locator('.evidence-details summary').click();
  await expect(page.locator('.chapter-list li')).toHaveCount(2);
  await expect(page.locator('.chapter-list li').first()).toContainText('有效未知字段章节');
  await expect(page.locator('.chapter-list li').first().locator('.chapter-time')).toHaveCount(0);
  await expect(page.locator('.chapter-list li').nth(1)).toContainText('起始时间 0:00');
  await expect(page.locator('.chapter-list li').nth(1)).toContainText('时长 0:01');
  await expect(page.locator('.chapter-list')).not.toContainText('不应验证');
  await expect(page.locator('.chapter-list a[href^="javascript:"], .chapter-list a[href*="secret@"]')).toHaveCount(0);
});

test('无对应目录证据不会显示已验证章节或把未知资源标成视频', async ({ page }) => {
  const unverified: ResourceItem = { ...otherItem, resource: { ...otherItem.resource, resource_type: 'unknown', metadata_evidence_level: 'catalog', chapters: [{ title: '无来源的目录', url: 'https://example.org/unverified', evidence_id: 'missing', start_seconds: 30 }] } };
  await setup(page, caps, baseJob, { ...results, groups: [{ ...results.groups[0], items: [unverified] }] });
  await page.goto('/?job=test-job');
  await expect(page.locator('.resource-meta')).toContainText('类型未知');
  await expect(page.locator('.evidence-label')).toHaveText('页面元信息');
  await page.locator('.evidence-details summary').click();
  await expect(page.locator('.chapter-list')).toHaveCount(0);
  await expect(page.locator('.catalog-empty')).toHaveText('暂无可获取的目录证据，不代表来源没有目录。');
  await expect(page.getByRole('link', { name: '无来源的目录' })).toHaveCount(0);
});

test('文字资料、课程视频和未知类型筛选互不混淆，可与平台筛选组合', async ({ page }) => {
  const textItem: ResourceItem = { ...otherItem, resource: { ...otherItem.resource, resource_type: 'article' } };
  const unknownItem: ResourceItem = { ...otherItem, resource: { ...otherItem.resource, resource_id: 'r3', title: '测试响应：未知类型', resource_type: 'unknown' }, match: { ...otherItem.match, resource_id: 'r3' } };
  await setup(page, caps, baseJob, { ...results, groups: [{ ...results.groups[0], items: [item, textItem, unknownItem] }] });
  await page.goto('/?job=test-job');
  await page.getByLabel('资源类型').selectOption('text');
  await expect(page.locator('.resource-card')).toHaveCount(1);
  await expect(page.locator('.resource-meta')).toContainText('文字教程');
  await page.getByLabel('资源类型').selectOption('learning');
  await expect(page.locator('.resource-card')).toHaveCount(1);
  await expect(page.locator('.platform-label')).toHaveText('B站');
  await page.getByLabel('来源平台').selectOption('other');
  await expect(page.locator('.resource-card')).toHaveCount(0);
  await expect(page.locator('.group-empty')).toContainText('当前筛选下暂无匹配资源');
  await page.getByLabel('资源类型').selectOption('unknown');
  await expect(page.locator('.resource-card')).toHaveCount(1);
  await expect(page.locator('.resource-meta')).toContainText('类型未知');
  await page.getByLabel('资源类型').selectOption('all');
  await page.getByLabel('来源平台').selectOption('all');
  await expect(page.locator('.resource-card')).toHaveCount(3);
});

test('目录跟随失败保留具体原因，条款核对与目录页计数单独展示', async ({ page }) => {
  const statuses = ['budget_limited', 'site_policy_blocked', 'network_error', 'future_source_state'];
  const entries = statuses.map((status, index): ResourceItem => ({ ...otherItem,
    resource: { ...otherItem.resource, resource_id: `follow-${index}`, title: `目录跟随 fixture ${index}`, catalog_fetch_status: status, fetch_status: index === 1 ? 'policy_unreviewed' : 'fetched' },
    evidence: [{ evidence_id: `policy-${index}`, kind: 'site_policy', source: 'official_policy_review', url: 'https://example.org/terms', text: '测试条款依据，仅用于UI fixture。', reviewed_at: time }],
  }));
  await setup(page, caps, { ...baseJob, progress: { ...baseJob.progress, details_cached: 3, catalog_pages_attempted: 2, catalog_pages_completed: 1 } }, { ...results, groups: [{ ...results.groups[0], items: entries }] });
  await page.goto('/?job=test-job');
  await expect(page.locator('.catalog-fetch-note').nth(0)).toHaveText('目录补全未完成：目录页采集预算不足');
  await expect(page.locator('.catalog-fetch-note').nth(1)).toHaveText('目录补全未完成：当前策略停止采集（查看来源依据）');
  await expect(page.locator('.catalog-fetch-note').nth(2)).toContainText('网络连接失败');
  await expect(page.locator('.catalog-fetch-note').nth(3)).toContainText('未知状态（future_source_state）');
  await expect(page.locator('.resource-card').nth(1).locator('.verification-note')).toContainText('采集许可尚未确认');
  await expect(page.locator('.progress-counts')).toContainText('详情采集 1 / 2');
  await expect(page.locator('.progress-counts')).toContainText('目录页采集 1 / 2');
  await expect(page.locator('.progress-counts')).toContainText('详情缓存 3');
  await page.locator('.evidence-details summary').nth(1).click();
  await expect(page.locator('.resource-card').nth(1).locator('.source-record')).toContainText('条款核对');
  await expect(page.locator('.resource-card').nth(1).locator('.source-record')).toContainText('测试条款依据，仅用于UI fixture。');
});

test('搜索视频候选、页面视频结构与普通页面证据严格区分，链接供原平台跳转', async ({ page }) => {
  const states = ['search_discovered', 'page_verified', 'none'] as const;
  const entries = states.map((status, index): ResourceItem => ({ ...otherItem,
    resource: { ...otherItem.resource, resource_id: `video-${index}`, title: `视频证据 fixture ${index}`, video_evidence_status: status, metadata_evidence_level: 'page', fetch_status: 'fetched' },
  }));
  await setup(page, caps, baseJob, { ...results, groups: [{ ...results.groups[0], items: entries }] });
  await page.goto('/?job=test-job');
  await expect(page.locator('.video-evidence-note').nth(0)).toContainText('搜索发现的视频候选');
  await expect(page.locator('.video-evidence-note').nth(0)).not.toContainText('页面含视频结构证据');
  await expect(page.locator('.video-evidence-note').nth(1)).toContainText('页面含视频结构证据');
  await expect(page.locator('.video-evidence-note').nth(2)).toContainText('暂无视频结构证据');
  await expect(page.locator('.video-evidence-note').nth(2)).not.toContainText('页面含视频结构证据');
  await expect(page.locator('.evidence-label').nth(2)).toHaveText('页面元信息');
  await expect(page.locator('.video-evidence-note').nth(1)).toContainText('点击链接前往原平台学习');
  await expect(page.locator('.access-line').nth(1)).toContainText('登录：');
});

test('公开课程入口搜索候选保留课程身份，不冒充已确认的视频', async ({ page }) => {
  const url = 'https://www.icourse163.org/course/TEST-123456';
  const course: ResourceItem = { ...otherItem,
    resource: { ...otherItem.resource, title: '课程候选 fixture', url, resource_type: 'course', platform: 'icourse163', video_evidence_status: 'none', metadata_evidence_level: 'search', fetch_status: 'search_only_policy',
      field_provenance: { resource_type: { evidence_id: 'course-search', source: 'url_pattern', url } } },
    evidence: [{ evidence_id: 'course-search', kind: 'search', source: 'searxng', url, observed_at: time }],
  };
  await setup(page, caps, baseJob, { ...results, groups: [{ ...results.groups[0], items: [course] }] });
  await page.goto('/?job=test-job');
  await expect(page.locator('.video-evidence-note')).toContainText('搜索发现的课程候选 · 是否含视频未核验');
  await expect(page.locator('.video-evidence-note')).not.toContainText('搜索发现的视频候选');
  await expect(page.locator('.video-evidence-note')).not.toContainText('页面含视频结构证据');
  await expect(page.locator('.evidence-label')).toHaveText('搜索发现');
  await expect(page.locator('.access-line')).toContainText('登录：');
});

test('取消执行中的任务只发一次请求，保留结果并停止轮询', async ({ page }, testInfo) => {
  await setup(page);
  let cancelled = false, cancels = 0, polls = 0;
  let release!: () => void;
  const gate = new Promise<void>(resolve => { release = resolve; });
  await page.route('**/api/search-jobs/test-job', route => { polls += 1; return route.fulfill({ json: { ...baseJob, status: cancelled ? 'cancelled' : 'running', phase: cancelled ? 'done' : 'searching' } }); });
  await page.route('**/api/search-jobs/test-job/results', route => route.fulfill({ json: { ...results, status: cancelled ? 'cancelled' : 'running' } }));
  await page.route('**/api/search-jobs/test-job/cancel', async route => {
    cancels += 1; expect(route.request().method()).toBe('POST');
    await gate; cancelled = true;
    await route.fulfill({ json: { job_id: 'test-job', status: 'cancelled', cancelled: true } });
  });
  await page.goto('/?job=test-job');
  await expect(page.locator('.resource-card')).toHaveCount(3);
  await page.getByRole('button', { name: '取消任务', exact: true }).evaluate(button => { (button as HTMLButtonElement).click(); (button as HTMLButtonElement).click(); });
  await expect(page.getByRole('button', { name: '正在取消…' })).toBeDisabled();
  await expect.poll(() => cancels).toBe(1);
  release();
  await expect(page.locator('.job-status')).toHaveText('任务已取消');
  await expect(page.getByText('已按你的操作取消')).toBeVisible();
  await expect(page.locator('.resource-card')).toHaveCount(3);
  await expect(page.getByRole('button', { name: '开始查找' })).toBeEnabled();
  await expect.poll(() => polls).toBeGreaterThan(1);
  const endedPolls = polls;
  await page.waitForTimeout(1700);
  expect(polls).toBe(endedPolls);
  await page.screenshot({ path: testInfo.outputPath('cancelled-preserved-results.png'), fullPage: true });
});

test('重复提交锁与后端复用原任务提示', async ({ page }) => {
  await setup(page);
  let submissions = 0;
  let release!: () => void;
  const gate = new Promise<void>(resolve => { release = resolve; });
  await page.route('**/api/search-jobs', async route => {
    submissions += 1; await gate;
    await route.fulfill({ status: 202, json: { job_id: 'test-job', status: 'running', reused: true } });
  });
  await page.goto('/');
  await page.getByLabel('知识点', { exact: true }).fill('隔离重复提交测试');
  await page.locator('form').evaluate(form => {
    form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
    form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
  });
  await expect.poll(() => submissions).toBe(1);
  await expect(page.getByRole('button', { name: '正在查找…' })).toBeDisabled();
  release();
  await expect(page.getByText('已返回相同需求的原任务，未重复发起搜索。')).toBeVisible();
  await expect(page.locator('.resource-card')).toHaveCount(3);
});

test('创建超时重试沿用幂等key，明确重新检索使用新key', async ({ page }) => {
  await page.clock.install();
  await setup(page);
  const keys: string[] = [];
  let release!: () => void;
  const gate = new Promise<void>(resolve => { release = resolve; });
  await page.route('**/api/search-jobs', async route => {
    keys.push(route.request().headers()['idempotency-key']);
    if (keys.length === 1) { await gate; await route.abort().catch(() => {}); return; }
    await route.fulfill({ status: 202, json: { job_id: keys.length === 2 ? 'test-job' : 'new-job', status: 'completed', reused: keys.length === 2 } });
  });
  await page.route('**/api/search-jobs/new-job', route => route.fulfill({ json: { ...baseJob, job_id: 'new-job' } }));
  await page.route('**/api/search-jobs/new-job/results', route => route.fulfill({ json: { ...results, job_id: 'new-job' } }));
  await page.goto('/');
  await page.getByLabel('知识点', { exact: true }).fill('隔离创建超时测试');
  await page.getByRole('button', { name: '开始查找' }).click();
  await expect.poll(() => keys.length).toBe(1);
  await page.clock.fastForward(15_001);
  await expect(page.getByRole('alert')).toContainText('创建状态尚未确认');
  await expect(page.getByRole('button', { name: '开始查找' })).toBeEnabled();
  release();
  await page.getByRole('button', { name: '开始查找' }).click();
  await expect(page.locator('.job-status')).toHaveText('检索完成');
  expect(keys[0]).toMatch(/^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/);
  expect(keys[1]).toBe(keys[0]);
  await expect(page.getByText('已返回相同需求的原任务，未重复发起搜索。')).toBeVisible();
  await page.getByRole('button', { name: '开始查找' }).click();
  await expect(page).toHaveURL(/job=new-job/);
  await expect(page.locator('.resource-card')).toHaveCount(3);
  expect(keys[2]).not.toBe(keys[1]);
});

test('取消后新任务不会被迟到的旧轮询覆盖', async ({ page }) => {
  await setup(page);
  let cancelled = false, resultCalls = 0;
  let releaseOld!: () => void;
  const oldGate = new Promise<void>(resolve => { releaseOld = resolve; });
  await page.route('**/api/search-jobs/test-job', route => route.fulfill({ json: { ...baseJob, status: cancelled ? 'cancelled' : 'running' } }));
  await page.route('**/api/search-jobs/test-job/results', async route => {
    resultCalls += 1;
    if (!cancelled) await oldGate;
    await route.fulfill({ json: { ...results, status: cancelled ? 'cancelled' : 'running' } }).catch(() => {});
  });
  await page.route('**/api/search-jobs/test-job/cancel', route => { cancelled = true; return route.fulfill({ json: { job_id: 'test-job', status: 'cancelled', cancelled: true } }); });
  await page.route('**/api/search-jobs', route => route.fulfill({ status: 202, json: { job_id: 'new-job', status: 'completed', reused: false } }));
  await page.route('**/api/search-jobs/new-job', route => route.fulfill({ json: { ...baseJob, job_id: 'new-job' } }));
  const newResults: SearchResults = { ...results, job_id: 'new-job', groups: [{ ...results.groups[0], items: [{ ...otherItem, resource: { ...otherItem.resource, title: '新任务的唯一结果' } }] }] };
  await page.route('**/api/search-jobs/new-job/results', route => route.fulfill({ json: newResults }));
  await page.goto('/?job=test-job');
  await expect.poll(() => resultCalls).toBeGreaterThanOrEqual(1);
  await page.getByRole('button', { name: '取消任务', exact: true }).click();
  await expect(page.locator('.job-status')).toHaveText('任务已取消');
  await page.getByLabel('知识点', { exact: true }).fill('新任务');
  await page.getByRole('button', { name: '开始查找' }).click();
  await expect(page.getByRole('heading', { name: '新任务的唯一结果' })).toBeVisible();
  releaseOld();
  await page.waitForTimeout(100);
  await expect(page.locator('.resource-card')).toHaveCount(1);
  await expect(page.getByRole('heading', { name: '新任务的唯一结果' })).toBeVisible();
  await expect(page).toHaveURL(/job=new-job/);
});

test('轮询任一请求失败会及时取消同轮兄弟请求', async ({ page }) => {
  await page.addInitScript(() => {
    const target = window as typeof window & { __fetchAudit: { url: string; aborted: boolean }[] };
    target.__fetchAudit = [];
    const nativeFetch = window.fetch.bind(window);
    window.fetch = (input, init) => {
      const entry = { url: String(input), aborted: false };
      target.__fetchAudit.push(entry);
      init?.signal?.addEventListener('abort', () => { entry.aborted = true; }, { once: true });
      return nativeFetch(input, init);
    };
  });
  await setup(page);
  let recovered = false;
  let release!: () => void;
  const gate = new Promise<void>(resolve => { release = resolve; });
  await page.route('**/api/search-jobs/test-job', route => {
    return route.fulfill(!recovered ? { status: 503, json: { detail: '隔离轮询故障' } } : { json: baseJob });
  });
  await page.route('**/api/search-jobs/test-job/results', async route => {
    if (!recovered) await gate;
    await route.fulfill({ json: results }).catch(() => {});
  });
  await page.goto('/?job=test-job');
  await expect(page.getByRole('alert')).toContainText('隔离轮询故障');
  await expect.poll(() => page.evaluate(() => {
    const entries = (window as typeof window & { __fetchAudit: { url: string; aborted: boolean }[] }).__fetchAudit.filter(entry => entry.url.endsWith('/results'));
    return entries.length >= 2 && entries.every(entry => entry.aborted);
  })).toBe(true);
  recovered = true; release();
  await expect(page.locator('.job-status')).toHaveText('检索完成');
  await expect(page.locator('.resource-card')).toHaveCount(3);
});

test('取消请求失败保持未确认状态，不假装取消成功', async ({ page }) => {
  await setup(page, caps, { ...baseJob, status: 'running', phase: 'searching' }, { ...results, status: 'running' });
  await page.route('**/api/search-jobs/test-job/cancel', route => route.abort('connectionreset'));
  await page.goto('/?job=test-job');
  await expect(page.locator('.job-status')).toHaveText('正在查找');
  await page.getByRole('button', { name: '取消任务', exact: true }).click();
  await expect(page.getByRole('alert')).toContainText('取消状态尚未确认');
  await expect(page.locator('.job-status')).toHaveText('正在查找');
  await expect(page.getByText('已按你的操作取消')).toHaveCount(0);
  await expect(page.getByRole('button', { name: '取消任务', exact: true })).toBeEnabled();
});

test('任务已自然结束时取消返回原终态，不覆盖为cancelled', async ({ page }) => {
  await setup(page);
  let completed = false;
  await page.route('**/api/search-jobs/test-job', route => route.fulfill({ json: { ...baseJob, status: completed ? 'completed' : 'running' } }));
  await page.route('**/api/search-jobs/test-job/results', route => route.fulfill({ json: { ...results, status: completed ? 'completed' : 'running' } }));
  await page.route('**/api/search-jobs/test-job/cancel', route => { completed = true; return route.fulfill({ json: { job_id: 'test-job', status: 'completed', cancelled: false } }); });
  await page.goto('/?job=test-job');
  await expect(page.locator('.job-status')).toHaveText('正在查找');
  await page.getByRole('button', { name: '取消任务', exact: true }).click();
  await expect(page.locator('.job-status')).toHaveText('检索完成');
  await expect(page.getByText('任务已结束，已保留原任务状态。')).toBeVisible();
  await expect(page.getByText('已按你的操作取消')).toHaveCount(0);
});

test('课程归属和讲次按证据显示，身份未知与统计范围如实标注', async ({ page }, testInfo) => {
  const url = 'https://www.icourse163.org/course/TEST-123456';
  const identity = { status: 'partial', family_id: 'source-course-1', offering_id: null, lesson_id: null, family_url: url, offering_url: null, role: 'course', basis: 'recognized_url', source_url: url, evidence_ids: ['identity-search'], unknown_reason: '开课学期尚未确认。' } as const;
  const identified: ResourceItem = { ...otherItem, resource: { ...otherItem.resource, title: '同来源课程身份 fixture', url, course_identity: { ...identity, evidence_ids: [...identity.evidence_ids] } }, evidence: [{ evidence_id: 'identity-search', kind: 'search', source: 'fixture', url: url + '?utm_source=fixture' }] };
  const unbacked: ResourceItem = { ...identified, resource: { ...identified.resource, resource_id: 'missing-identity', title: '缺少身份依据 fixture', course_identity: { ...identity, family_id: 'fabricated', lesson_id: 'fabricated-lesson', evidence_ids: ['missing'] } } };
  await setup(page, caps, baseJob, { ...results, groups: [{ ...results.groups[0], items: [identified, unbacked, item] }], identity_summary: { resource_records: 3, identified_course_families: 1, identified_course_offerings: 0, identified_lessons: 0, unknown_course_family_resources: 2, unknown_offering_resources: 3, unknown_identity_resources: 2, scope: 'observed_source_scoped_identities_not_global_course_deduplication' } });
  await page.goto('/?job=test-job');
  await expect(page.locator('.identity-note').nth(0)).toContainText('课程归属：已识别同来源课程 · 开课版本：未知 · 讲次：未知');
  await expect(page.locator('.identity-note').nth(1)).toContainText('课程归属：未知 · 开课版本：未知 · 讲次：未知');
  await expect(page.locator('.identity-note').nth(2)).toContainText('课程归属：未知');
  await expect(page.locator('.identity-summary')).toContainText('不是跨网站独立课程总数');
  await page.locator('.evidence-details summary').first().click();
  await expect(page.getByRole('link', { name: '查看同来源课程入口' })).toHaveAttribute('href', url);
  await expect(page.locator('.identity-details').first()).toContainText('开课学期尚未确认');
  await page.screenshot({ path: testInfo.outputPath('identity-evidence-desktop.png'), fullPage: true });
  await page.setViewportSize({ width: 390, height: 844 });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await page.locator('.identity-note').last().scrollIntoViewIfNeeded();
  await expect(page.locator('.identity-note').last()).toBeVisible();
  await page.locator('.identity-note').first().scrollIntoViewIfNeeded();
  await expect(page.locator('.identity-details').first()).toBeVisible();
  // Capture the actual visible card; offscreen content-visibility placeholders
  // in a full-page screenshot do not represent the mobile reading experience.
  await page.screenshot({ path: testInfo.outputPath('identity-evidence-mobile.png') });
});

test('平台采集政策不冒充浏览器访问结论或全平台完成', async ({ page }, testInfo) => {
  const capability: Capabilities = { ...caps, platforms: [
    { id: 'bilibili', name: 'B站', discovery: 'search', metadata: 'site_policy_blocked', playback: 'unknown', source_url: 'https://example.org/terms', reviewed_at: time },
    { id: 'icourse163', name: '中国大学 MOOC', discovery: 'search', metadata: 'policy_unreviewed', playback: 'unknown' },
  ] };
  await setup(page, capability);
  await page.goto('/?job=test-job');
  await expect(page.locator('.completion-boundary')).toContainText('不代表每个平台均有结果');
  await expect(page.locator('.access-line').first()).toContainText('浏览器访问：未逐页实测');
  await page.locator('.capabilities-footer summary').click();
  await expect(page.locator('.platform-capabilities section').first()).toContainText('当前政策停止自动采集');
  await expect(page.locator('.platform-capabilities section').nth(1)).toContainText('自动采集许可范围待确认');
  await expect(page.locator('.capabilities-detail')).toContainText('自动采集停止不表示用户无法浏览');
  await expect(page.locator('.capabilities-detail')).toContainText('在线浏览器采集回退：已关闭');
  await expect(page.locator('.capabilities-detail')).toContainText('受控 JS 补全：未知（服务端未返回）');
  await expect(page.locator('.platform-capabilities')).not.toContainText('浏览器无法访问');
  await page.screenshot({ path: testInfo.outputPath('platform-policy-boundaries.png'), fullPage: true });
});

test('可靠普通课程与显式父课程讲次分别展示，缺失或冲突证据保持未知', async ({ page }) => {
  const courseUrl = 'https://example.org/course';
  const lessonUrl = 'https://example.org/lesson/one';
  const commonIdentity = { status: 'identified', family_id: 'course-fixture', offering_id: null, lesson_id: null, family_url: courseUrl, offering_url: null, role: 'course', basis: 'page_course', source_url: courseUrl, evidence_ids: ['course-type'], unknown_reason: null } as const;
  const course: ResourceItem = { ...otherItem, resource: { ...otherItem.resource, title: '普通课程结构 fixture', url: courseUrl, resource_type: 'course', video_evidence_status: 'none', course_identity: { ...commonIdentity, evidence_ids: ['course-type'] }, field_provenance: { resource_type: { evidence_id: 'course-type', source: 'jsonld.@type', url: courseUrl } } }, evidence: [{ evidence_id: 'course-type', kind: 'page', field: 'resource_type', source: 'jsonld.@type', url: courseUrl, text: 'course' }] };
  const parentRecord: Evidence = { evidence_id: 'parent-relation', kind: 'page', field: 'parent_course_url', source: 'jsonld.isPartOf.Course', url: lessonUrl, text: JSON.stringify({ '@type': 'Course', url: courseUrl }) };
  const lesson: ResourceItem = { ...otherItem, resource: { ...otherItem.resource, resource_id: 'lesson-fixture', title: '显式课程讲次 fixture', url: lessonUrl, parent_course_url: courseUrl, course_identity: { ...commonIdentity, role: 'lesson', basis: 'page_is_part_of', source_url: lessonUrl, lesson_id: 'lesson-one', evidence_ids: ['parent-relation'] }, field_provenance: { parent_course_url: { evidence_id: 'parent-relation', source: 'jsonld.isPartOf.Course', url: lessonUrl } } }, evidence: [parentRecord] };
  const conflict: ResourceItem = { ...lesson, resource: { ...lesson.resource, resource_id: 'conflict-fixture', title: '父课程关系冲突 fixture', parent_course_url: 'https://different.example.org/course' } };
  const genericOutline: ResourceItem = { ...course, resource: { ...course.resource, resource_id: 'generic-outline-fixture', title: '普通页面目录不能证明课程 fixture', field_provenance: { resource_type: { evidence_id: 'course-type', source: 'html.visible_course_outline', url: courseUrl } } }, evidence: [{ ...course.evidence[0], source: 'html.visible_course_outline' }] };
  await setup(page, caps, baseJob, { ...results, groups: [{ ...results.groups[0], items: [course, lesson, conflict, genericOutline] }] });
  await page.goto('/?job=test-job');
  await expect(page.locator('.video-evidence-note').first()).toContainText('页面含课程结构证据 · 是否含视频未核验');
  await expect(page.locator('.video-evidence-note').first()).not.toContainText('页面含视频结构证据');
  await expect(page.locator('.identity-note').nth(1)).toContainText('课程归属：已识别同来源课程 · 开课版本：未知 · 讲次：已识别');
  await expect(page.locator('.identity-note').nth(2)).toContainText('课程归属：未知 · 开课版本：未知 · 讲次：未知');
  await expect(page.locator('.identity-note').nth(3)).toContainText('课程归属：未知');
  await expect(page.locator('.video-evidence-note').nth(3)).not.toContainText('页面含课程结构证据');
  await expect(page.locator('.access-line').first()).toContainText('登录：');
});

test('受控 JS 状态与真实字段增益分开，课程表证据兼容且 DOM 哈希仅作来源记录', async ({ page }, testInfo) => {
  const source = 'html.microsoft_ai.curriculum_table';
  const url = 'https://microsoft.github.io/AI-For-Beginners/';
  const acquisition = { acquisition: 'offline_rendered_dom', render_id: 'render-fixture', dom_sha256: 'a'.repeat(64) };
  const chapters: Chapter[] = [{ title: 'Fixture chapter A', url: null, evidence_id: 'render-chapter-0' }, { title: 'Fixture chapter B', url: null, evidence_id: 'render-chapter-1' }];
  const dynamic: ResourceItem = { ...otherItem, resource: { ...otherItem.resource, resource_id: 'render-gain', title: '动态课程 fixture', url,
    resource_type: 'course', video_evidence_status: 'none', metadata_evidence_level: 'catalog', chapters,
    field_provenance: { resource_type: { ...acquisition, evidence_id: 'render-type', source, url }, chapters: { ...acquisition, evidence_id: 'render-catalog', source, url } },
    render_diagnostics: { ...acquisition, status: 'rendered', source_url: url, static_chapter_count: 0, rendered_chapter_count: 2, added_fields: ['resource_type', 'chapters'] } },
    evidence: [{ ...acquisition, evidence_id: 'render-type', kind: 'page', field: 'resource_type', source, url, text: 'Observed public curriculum table' },
      { ...acquisition, evidence_id: 'render-catalog', kind: 'catalog', field: 'chapters', source, url, text: JSON.stringify(chapters) },
      ...chapters.map((chapter, index) => ({ ...chapterEvidence(chapter, index), ...acquisition, url, source }))] };
  const noGain: ResourceItem = { ...otherItem, resource: { ...otherItem.resource, resource_id: 'render-no-gain', title: '执行无增益 fixture',
    render_diagnostics: { ...acquisition, status: 'rendered', static_chapter_count: 0, rendered_chapter_count: 0, added_fields: ['chapters'] } } };
  const timeout: ResourceItem = { ...otherItem, resource: { ...otherItem.resource, resource_id: 'render-timeout', title: '动态超时 fixture',
    render_diagnostics: { status: 'render_timeout', static_chapter_count: 0, dom_sha256: '<img src=x onerror=alert(1)>' } } };
  await setup(page, caps, baseJob, { ...results, groups: [{ ...results.groups[0], items: [dynamic, noGain, timeout] }] });
  await page.goto('/?job=test-job');
  await expect(page.locator('.resource-card')).toHaveCount(3);
  for (const card of await page.locator('.resource-card').all()) await card.getByText('查看来源与证据', { exact: true }).click();
  const cards = page.locator('.resource-card');
  await expect(cards.nth(0).locator('.video-evidence-note')).toContainText('页面含课程结构证据 · 是否含视频未核验');
  await expect(cards.nth(0).locator('.render-diagnostics')).toContainText('静态目录项：0 · DOM 提取目录项：2');
  await expect(cards.nth(0).locator('.render-diagnostics')).toContainText('可对应来源的新增字段：课程类型、目录');
  await expect(cards.nth(0).locator('.chapter-list li')).toHaveCount(2);
  await expect(cards.nth(0).locator('.render-diagnostics code')).toHaveText('a'.repeat(64));
  await expect(cards.nth(1).locator('.render-diagnostics')).toContainText('离线执行完成（不代表字段有增益）');
  await expect(cards.nth(1).locator('.render-diagnostics')).toContainText('可对应来源的新增字段：尚未确认');
  await expect(cards.nth(2).locator('.render-diagnostics')).toContainText('状态：补全超时');
  await expect(cards.nth(2).locator('.render-diagnostics')).toContainText('DOM 提取目录项：未知');
  await expect(cards.nth(2).locator('.render-diagnostics code')).toHaveText('未知');
  await expect(page.locator('.render-diagnostics img')).toHaveCount(0);
  await expect(cards.nth(0).locator('.access-line')).toContainText('登录：');
  await page.setViewportSize({ width: 390, height: 844 });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBeTruthy();
  await page.screenshot({ path: testInfo.outputPath('render-diagnostics-mobile.png'), fullPage: true });
});

test('受控 JS 配置与在线回退及动态可用性分开', async ({ page }, testInfo) => {
  const capability: Capabilities = { ...caps, js_render: { enabled: true, status: 'configured', allowed_hosts: ['microsoft.github.io'], asset_hosts: ['cdn.jsdelivr.net'],
    timeout_seconds: 20, max_resources: 6, max_target_requests: 12, max_doh_requests: 24, max_total_bytes: 2_000_000,
    max_dom_bytes: 1_000_000, max_observed_data_resources: 2, online_browser_fallback: false,
    message: '仅显式允许来源；公开资源经安全采集后离线执行', process_network_egress: 'unknown', playback_verified: false } };
  await setup(page, capability);
  await page.goto('/');
  await page.locator('.capabilities-footer summary').click();
  const detail = page.locator('.capabilities-detail');
  await expect(detail).toContainText('在线浏览器采集回退：已关闭');
  await expect(detail).toContainText('受控 JS 补全：已配置，动态增益需逐页核对');
  await expect(detail).toContainText('允许页面来源：microsoft.github.io · 允许跨源资产：cdn.jsdelivr.net');
  await expect(detail).toContainText('单次补全上限：6 个资产 · 12 次补充目标请求 · 24 次 DoH · 20 秒');
  await expect(detail).not.toContainText('已验证动态采集成功');
  await page.screenshot({ path: testInfo.outputPath('render-capability-configured.png'), fullPage: true });
  await page.route('**/api/capabilities', route => route.fulfill({ json: { ...capability, js_render: { ...capability.js_render, enabled: false, status: 'disabled' } } }));
  await page.getByRole('button', { name: '重新检查服务状态' }).click();
  await expect(detail).toContainText('受控 JS 补全：已关闭');
});

test('创建响应丢失后刷新可按原幂等key恢复已结束任务，确认后清除tab存储', async ({ page }, testInfo) => {
  await setup(page);
  const requests: { key: string | undefined; body: unknown }[] = [];
  await page.route('**/api/search-jobs', async route => {
    requests.push({ key: route.request().headers()['idempotency-key'], body: route.request().postDataJSON() });
    if (requests.length === 1) return route.abort('connectionreset');
    return route.fulfill({ status: 202, json: { job_id: 'test-job', status: 'completed', reused: true } });
  });
  await page.goto('/');
  await page.getByLabel('知识点', { exact: true }).fill('响应丢失后的原知识点');
  await page.getByLabel('学生基础').selectOption('intermediate');
  await page.getByLabel('学习语言').selectOption('en');
  await page.getByLabel('技术版本').fill('fixture version');
  await page.getByLabel('项目背景').fill('fixture background');
  await page.getByRole('button', { name: '开始查找' }).click();
  await expect(page.getByText(/创建状态尚未确认/)).toBeVisible();
  const beforeReload = await page.evaluate(() => sessionStorage.getItem('knowledge-guide.pending-creation.v1'));
  expect(JSON.parse(beforeReload!).key).toBe(requests[0].key);
  await page.reload();
  const recovery = page.getByRole('region', { name: '未确认提交恢复' });
  await expect(recovery).toContainText('响应丢失后的原知识点');
  expect(requests).toHaveLength(1);
  await recovery.getByText('查看原学习需求').click();
  await expect(recovery).toContainText('fixture version');
  await expect(recovery).toContainText('fixture background');
  await page.screenshot({ path: testInfo.outputPath('submission-recovery-desktop.png'), fullPage: true });
  await page.getByRole('button', { name: '继续上次未确认提交' }).click();
  await expect(page.locator('.job-status')).toHaveText('检索完成');
  await expect(page).toHaveURL(/job=test-job/);
  await expect(page.locator('.resource-card')).toHaveCount(3);
  expect(requests).toHaveLength(2);
  expect(requests[1]).toEqual(requests[0]);
  expect(await page.evaluate(() => sessionStorage.getItem('knowledge-guide.pending-creation.v1'))).toBeNull();
  await expect(recovery).toHaveCount(0);
  await page.reload();
  await expect(page.locator('.resource-card')).toHaveCount(3);
  expect(requests).toHaveLength(2);
});

test('刷新后的不同需求不会使用旧幂等key，清除入口不会请求取消', async ({ page }) => {
  await setup(page);
  const keys: (string | undefined)[] = [];
  const bodies: unknown[] = [];
  await page.route('**/api/search-jobs', async route => {
    keys.push(route.request().headers()['idempotency-key']); bodies.push(route.request().postDataJSON());
    if (keys.length < 3) return route.abort('connectionreset');
    return route.fulfill({ status: 202, json: { job_id: 'test-job', status: 'completed' } });
  });
  await page.goto('/');
  await page.getByLabel('知识点', { exact: true }).fill('旧的未确认需求');
  await page.getByRole('button', { name: '开始查找' }).click();
  await expect(page.getByText(/创建状态尚未确认/)).toBeVisible();
  await page.reload();
  await page.getByLabel('知识点', { exact: true }).fill('不同的新需求');
  await page.getByRole('button', { name: '开始查找' }).click();
  await expect(page.getByText(/创建状态尚未确认/)).toBeVisible();
  expect(keys[1]).not.toBe(keys[0]);
  expect(bodies[1]).not.toEqual(bodies[0]);
  await expect(page.getByRole('region', { name: '未确认提交恢复' })).toContainText('不同的新需求');
  await page.getByRole('button', { name: '清除此恢复入口' }).click();
  expect(await page.evaluate(() => sessionStorage.getItem('knowledge-guide.pending-creation.v1'))).toBeNull();
  await expect(page.getByRole('button', { name: '继续上次未确认提交' })).toHaveCount(0);
  await page.getByRole('button', { name: '开始查找' }).click();
  await expect(page.locator('.job-status')).toHaveText('检索完成');
  expect(keys[2]).not.toBe(keys[1]);
});
