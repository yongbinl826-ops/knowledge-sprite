"""Read an observed Bilibili multipart selector, without playing or fetching media."""
from __future__ import annotations

import re
from urllib.parse import urljoin, urlsplit

from bs4 import BeautifulSoup

from ..url_utils import UnsafeURL, normalize_url
from .base import FieldFact, SourceFacts, clean_text


def _video_url(url: str) -> str | None:
    try:
        normalized = normalize_url(url)
        parsed = urlsplit(normalized)
    except (UnsafeURL, ValueError):
        return None
    if parsed.hostname not in {"bilibili.com", "www.bilibili.com"}:
        return None
    if not re.fullmatch(r"/video/(?:BV[0-9A-Za-z]{10}|av\d+)/?", parsed.path):
        return None
    return normalized


def part_duration_seconds(value: str | None) -> int | None:
    """The visible MM:SS / H:MM:SS is a part duration, never an offset."""
    value = clean_text(value, 20)
    if not value or not re.fullmatch(r"\d{1,3}:[0-5]\d(?::[0-5]\d)?", value):
        return None
    fields = [int(part) for part in value.split(":")]
    seconds = fields[0] * 60 + fields[1] if len(fields) == 2 else fields[0] * 3600 + fields[1] * 60 + fields[2]
    return seconds if seconds > 0 else None


class BilibiliAdapter:
    name = "bilibili_video_parts"

    def matches(self, url: str) -> bool:
        return _video_url(url) is not None

    def extract(self, soup: BeautifulSoup, url: str) -> SourceFacts:
        result = SourceFacts()
        page_url = _video_url(url)
        if not page_url:
            return result
        heading = soup.select_one("h1.video-title")
        title = clean_text(heading.get_text(" ", strip=True), 500) if heading else None
        if title:
            result.fields.append(FieldFact("title", title, "html.bilibili.video_title"))
        for pod in soup.select(".video-pod")[:3]:
            label = pod.select_one(".video-pod__header .title")
            if not label or clean_text(label.get_text(" ", strip=True), 100) != "视频选集":
                continue
            multip = pod.select_one(".video-pod__list.multip")
            if not multip:
                continue
            for item in multip.select(":scope > .video-pod__item")[:100]:
                title_tag = item.select_one(".title-txt") or item.select_one(".title")
                part_title = clean_text(title_tag.get_text(" ", strip=True), 300) if title_tag else None
                if not part_title:
                    continue
                duration = item.select_one(".stats .duration")
                # A CID/data-key or the item's position is not a page URL. Only
                # an actual same-video link in the title can supply a URL.
                anchor = item if item.name == "a" and item.has_attr("href") else item.select_one("a.title[href], .title a[href]")
                part_url = None
                if anchor:
                    actual_url = _video_url(urljoin(page_url, str(anchor.get("href", ""))))
                    if actual_url and urlsplit(actual_url).path.rstrip("/") == urlsplit(page_url).path.rstrip("/"):
                        part_url = actual_url
                result.chapters.append({
                    "title": part_title, "url": part_url, "source_url": page_url,
                    "start_seconds": None, "end_seconds": None,
                    "duration_seconds": part_duration_seconds(duration.get_text(" ", strip=True) if duration else None),
                })
            if result.chapters:
                result.catalog_source = "html.bilibili.video_pod.multip"
                result.catalog_kind = "video_parts"
                result.fields.extend([
                    FieldFact("resource_type", "video", result.catalog_source,
                              "Bilibili video page has a visible 视频选集 multipart selector; parts are distinct videos, not timeline chapters"),
                    FieldFact("video_evidence_status", "page_verified", result.catalog_source,
                              "Observed video page structure and ordered multipart selector; playback was not tested and no media was requested"),
                ])
                break
        return result
