"""Read the public MOOC course introduction and its textual curriculum only."""
from __future__ import annotations

import re
from urllib.parse import urlsplit

from bs4 import BeautifulSoup

from ..url_utils import UnsafeURL, normalize_url
from .base import FieldFact, SourceFacts, clean_text


def _course_url(url: str) -> str | None:
    try:
        normalized = normalize_url(url)
        parsed = urlsplit(normalized)
    except (UnsafeURL, ValueError):
        return None
    if parsed.hostname not in {"icourse163.org", "www.icourse163.org"}:
        return None
    if not re.fullmatch(r"/course/(?:[A-Za-z0-9_]+)?-\d+/?", parsed.path):
        return None
    return normalized


def outline_duration_seconds(value: str | None) -> int | float | None:
    """An explicit trailing '(Nmin)' describes this item, not a playable URL."""
    value = clean_text(value, 500)
    if not value:
        return None
    match = re.search(r"[（(]\s*(\d{1,5}(?:\.\d{1,3})?)\s*min\s*[）)]\s*$", value, re.I)
    if not match:
        return None
    seconds = float(match.group(1)) * 60
    return (int(seconds) if seconds.is_integer() else seconds) if seconds > 0 else None


class ICourse163Adapter:
    name = "icourse163_course_outline"

    def matches(self, url: str) -> bool:
        return _course_url(url) is not None

    def extract(self, soup: BeautifulSoup, url: str) -> SourceFacts:
        result = SourceFacts()
        page_url = _course_url(url)
        if not page_url:
            return result
        for button in soup.select(".course-enroll-info_course-enroll_buttons .course-enroll-info_course-enroll_buttons_enroll-btn .ux-btn")[:5]:
            notice = clean_text(button.get_text(" ", strip=True), 500)
            if notice and re.fullmatch(r"老师已关闭该学期[，,]\s*无法查看[。.!！]?", notice):
                result.fields.append(FieldFact("access_notice", notice, "html.icourse163.enrollment_notice"))
                break
        introduction = soup.select_one("#j-course-heading-intro .course-heading-intro_intro")
        outline = soup.select_one("#j-course-outline")
        # The route alone is search discovery. The source-specific introduction
        # and curriculum container establish an observed course page.
        if introduction is None or outline is None:
            return result
        description = clean_text(introduction.get_text(" ", strip=True))
        if not description:
            return result
        result.fields.extend([
            FieldFact("description", description, "html.icourse163.course_introduction"),
            FieldFact("resource_type", "course", "html.icourse163.course_structure",
                      "Observed MOOC course introduction and course-outline container; this is curriculum evidence, not video playback evidence"),
        ])
        for paragraph in outline.select(".f-richEditorText p")[:100]:
            title = clean_text(paragraph.get_text(" ", strip=True), 300)
            if not title:
                continue
            # The curriculum also contains headings, quizzes and assignments.
            # Preserve their literal labels; no lesson/media URLs are inferred.
            result.chapters.append({
                "title": title, "url": None, "source_url": page_url,
                "start_seconds": None, "end_seconds": None,
                "duration_seconds": outline_duration_seconds(title),
            })
        if result.chapters:
            result.catalog_source = "html.icourse163.course_outline.text"
            result.catalog_kind = "course_outline"
        return result
