import { useState } from 'react';
import { dateLabel, externalUrl, platformNames, statusNames } from '../api';
import type { Capabilities, CollectionCoverage, SearchJob, SearchResults } from '../types';
import { ResourceCard } from './ResourceCard';
import { SearchIcon } from './Icons';
import { collectionCoverageRows, groupItems, resultSections, visibleGroupItems, type VisibleItem } from '../topicEvidence';

const phaseNames: Record<string, string> = { queued: '等待执行', expanding: '生成查询词', searching: '搜索课程与视频', fetching: '补全公开元信息', ranking: '匹配与排序', done: '已结束' };
const isRunning = (job: SearchJob) => ['queued', 'running'].includes(job.status);
function CollectionEvidence({ coverage, items }: { coverage: CollectionCoverage | undefined; items: VisibleItem[] }) {
  if (coverage?.decomposition_status !== 'applied' || !coverage.subtopics.length) return null;
  const rows = collectionCoverageRows(coverage, items);
  const supported = rows.filter(row => row.sources.length > 0).length;
  return <section className="collection-coverage" aria-label="当前显示资源的互补覆盖">
    <h4>当前显示资源的互补覆盖</h4>
    {!!coverage.shared_context.length && <p>共同范围：{coverage.shared_context.join('、')}</p>}
    <p className="collection-coverage-count">{supported} / {rows.length} 个子项有文字证据；{rows.length - supported} 个子项仍未知。</p>
    <ul>{rows.map(({ part, sources }) => <li key={part.id}><strong>{part.text}</strong><span className={sources.length ? 'subtopic-supported' : 'subtopic-unknown'}>{sources.length ? '有证据支持' : '未知'}</span>
      {sources.length ? <ul>{sources.map(({ item, ids }) => <li key={item.resource.resource_id}>
        {externalUrl(item.resource.url) ? <a href={externalUrl(item.resource.url)} target="_blank" rel="noopener noreferrer">{item.resource.title || '标题未知'}</a> : <span>{item.resource.title || '标题未知'}</span>}
        <span className="collection-source-id">资源：<code>{item.resource.resource_id}</code> · 证据：{ids.map(id => <code key={id}>{id}</code>)}</span>
      </li>)}</ul> : <p>当前显示的明确推荐和部分覆盖候选尚未提供该子项依据。</p>}
    </li>)}</ul>
    <p className="coverage-boundary">集合中的资源可以互补，不代表其中任一条覆盖整个知识点，也不代表已核验完整教学覆盖。待核实线索不参与集合覆盖。</p>
  </section>;
}
type Props = { capabilities: Capabilities | null; capabilityError: string; job: SearchJob | null; results: SearchResults | null; jobId: string; error: string; notice: string; canCancel: boolean; cancelling: boolean; onCancel: () => void; onRetry: () => void; onRefresh: () => void };
export function ResultsPanel({ capabilities, capabilityError, job, results, jobId, error, notice, canCancel, cancelling, onCancel, onRetry, onRefresh }: Props) {
  const [filter, setFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const platforms = [...new Set(results?.groups.flatMap(group => [...resultSections.flatMap(section => Object.keys(group[section.platforms] || {})), ...groupItems(group).map(item => item.resource.platform)]) || [])];
  const activeFilter = platforms.includes(filter) ? filter : 'all';
  const pointMap = new Map<string, string[]>();
  for (const group of results?.groups || []) for (const item of groupItems(group)) {
    pointMap.set(item.resource.resource_id, [...new Set([...(pointMap.get(item.resource.resource_id) || []), group.text])]);
  }
  const warnings = [...new Set([...(job?.warnings || []), ...(results?.warnings || [])])];
  const unconfigured = capabilities?.search.status === 'unconfigured';
  const fault = capabilities?.search.status === 'fault';
  return <section className="results-panel panel" aria-labelledby="results-title">
    <div className="section-heading"><div><h2 id="results-title">学习资源</h2><p>按知识点整理 · 保留来源证据</p></div>{job && <span className={`job-status status-${job.status}`}>{statusNames[job.status]}</span>}</div>
    {capabilityError && <div className="notice error-notice" role="alert"><strong>暂时无法连接后端</strong><p>{capabilityError}</p><button className="text-button" onClick={onRefresh}>重新检查连接</button></div>}
    {(unconfigured || fault) && <div className="notice warning-notice"><span className="notice-icon" aria-hidden="true">!</span><div><strong>{unconfigured ? '搜索服务尚未配置' : '搜索服务暂时不可用'}</strong><p>{capabilities?.search.message || '请先在服务端接入 SearXNG，或启用已配置的 Tavily。'}</p></div></div>}
    {error && <div className="notice error-notice" role="alert"><strong>请求未完成</strong><p>{error}</p>{jobId && <button className="text-button" onClick={onRetry}>重新读取任务</button>}</div>}
    {notice && <p className="action-notice" role="status">{notice}</p>}
    {canCancel && <div className="task-actions"><button className="secondary-button" disabled={cancelling} onClick={onCancel}>{cancelling ? '正在取消…' : '取消任务'}</button><span>取消后保留已获取的结果与证据。</span></div>}
    {job && <div className="task-progress" aria-live="polite"><div className="progress-title"><strong>{phaseNames[job.phase] || job.phase}</strong><span>更新于 {dateLabel(job.updated_at)}</span></div><div className="progress-counts"><span>查询 <b>{job.progress.queries_completed} / {job.progress.queries_planned}</b></span><span>发现候选 <b>{job.progress.candidates_discovered}</b></span><span>详情采集 <b>{job.progress.details_completed} / {job.progress.details_attempted}</b></span>{job.progress.catalog_pages_attempted != null && <span>目录页采集 <b>{job.progress.catalog_pages_completed ?? 0} / {job.progress.catalog_pages_attempted}</b></span>}{job.progress.details_cached != null && <span>详情缓存 <b>{job.progress.details_cached}</b></span>}<span>缓存命中 <b>{job.progress.cache_hits}</b></span></div><p>实际搜索请求：{job.progress.search_requests} / {job.budgets.max_search_requests} 次；详情与目录页共用 {job.budgets.max_detail_pages} 页预算，采集计数分别列示。</p></div>}
    {job?.status === 'partial' && <div className="notice warning-notice"><strong>部分搜索或信息补全未完成</strong><p>已保留当前可用结果；请结合下方失败记录判断搜索范围。</p></div>}
    {job?.status === 'completed' && <p className="completion-boundary">本次任务流程已结束；不代表每个平台均有结果。目录为可选补充，点击链接前往原平台学习。</p>}
    {job?.status === 'cancelled' && <div className="notice warning-notice"><strong>已按你的操作取消</strong><p>已获取的结果与来源证据仍可查看；未完成部分保持未知。再次开始查找会创建新任务。</p></div>}
    {job?.status === 'interrupted' && <div className="notice warning-notice"><strong>任务已中断</strong><p>服务重启中断了该任务。已保存的结果仍可查看，请重新提交学习需求以再次执行。</p></div>}
    {job?.status === 'failed' && <div className="notice error-notice" role="alert"><strong>本次检索未能完成</strong><p>请检查搜索服务配置或网络连接后重新提交。</p></div>}
    {(warnings.length > 0 || !!job?.errors.length) && <details className="task-records"><summary>搜索范围与异常记录（{warnings.length + (job?.errors.length || 0)}）</summary><ul>{warnings.map((warning, index) => <li key={`w${index}`}>{warning}</li>)}{job?.errors.map((record, index) => <li key={`e${index}`}>{record.message} <code>{record.code}</code></li>)}</ul></details>}
    {results && <>
      {results.identity_summary?.scope === 'observed_source_scoped_identities_not_global_course_deduplication' && <p className="identity-summary">已返回 {results.identity_summary.resource_records} 条资源；识别到 {results.identity_summary.identified_course_families} 个同来源课程身份、{results.identity_summary.identified_course_offerings} 个开课版本、{results.identity_summary.identified_lessons} 个讲次身份。{results.identity_summary.unknown_course_family_resources} 条资源的课程归属未知。统计仅针对已返回资源，不是跨网站独立课程总数。</p>}
      <div className="results-toolbar"><div className="result-filter"><label htmlFor="platform-filter">来源平台</label><select id="platform-filter" value={activeFilter} onChange={e => setFilter(e.target.value)}><option value="all">全部平台</option>{platforms.map(platform => <option key={platform} value={platform}>{platformNames[platform] || platform}</option>)}</select></div><div className="result-filter"><label htmlFor="resource-type-filter">资源类型</label><select id="resource-type-filter" value={typeFilter} onChange={e => setTypeFilter(e.target.value)}><option value="all">全部类型</option><option value="learning">课程与视频</option><option value="text">文字资料</option><option value="unknown">类型未知</option></select></div><span>每个知识点按支持程度分开展示，每分类分别限额</span></div>
      <div className="result-groups">{results.groups.map(group => {
        const limit = group.section_limit && group.section_limit > 0 ? group.section_limit : capabilities?.limits.max_results_per_point || 5;
        const visibleItems = visibleGroupItems(group, activeFilter, typeFilter, limit);
        const counts = resultSections.map(section => visibleItems.filter(row => row.status === section.status).length);
        const collection = group.collection_coverage || group.platform_collection_coverage?.[activeFilter];
        return <section className="result-group" key={group.knowledge_point_id} aria-labelledby={`group-${group.knowledge_point_id}`}><div className="group-heading"><h3 id={`group-${group.knowledge_point_id}`}>{group.text}</h3><span>{counts[0]} 条明确 · {counts[1]} 条部分 · {counts[2]} 条待核</span></div>
          <p className="section-limit">每分类最多 {limit} 条；部分覆盖和待核线索分别列出，不计入明确主题推荐。</p>
          <CollectionEvidence coverage={collection} items={visibleItems}/>
          {!visibleItems.length ? <div className="group-empty">{groupItems(group).length ? '当前筛选下暂无匹配资源，可切换到“全部平台”和“全部类型”。' : job && isRunning(job) ? '仍在查找，结果将在完成后逐步出现。' : job?.status === 'cancelled' ? '取消前尚未保存匹配资源，不能判断是否存在合适课程。' : job?.status === 'failed' ? '搜索服务未成功返回结果，不能判断是否存在合适课程。' : job?.status === 'interrupted' ? '任务中断前未保存匹配资源。' : job?.status === 'partial' ? '当前有限搜索范围内暂无符合条件的课程。' : '本次检索未找到符合条件的课程。可以调整知识点或语言后再试。'}</div> : resultSections.map(section => {
            const rows = visibleItems.filter(row => row.status === section.status);
            if (!rows.length && section.status !== 'supported') return null;
            return <section className={`topic-section section-${section.status}`} key={section.status} aria-label={section.label}>
              <h4 className="topic-section-title">{section.label}<span>{rows.length} 条</span></h4>
              {section.status === 'needs_review' && <p className="topic-section-note">这些线索的主题或教学证据仍有缺口，请先查看逐条理由。它们不属于明确主题推荐。</p>}
              {section.status === 'partial' && <p className="topic-section-note">每条仅支持列出的子项，未支持的部分保持未知。</p>}
              {rows.length ? rows.map(({ item, status }) => <ResourceCard key={item.resource.resource_id} item={item} placement={status} points={pointMap.get(item.resource.resource_id) || [group.text]}/>) : <p className="supported-empty">当前显示范围内暂无明确支持整个知识点的推荐。</p>}
            </section>;
          })}
        </section>;
      })}</div>
      {!!results.search_attempts.length && <details className="task-records"><summary>查看实际查询记录（{results.search_attempts.length}）</summary><div className="query-records">{results.search_attempts.map((attempt, index) => <div key={index}><strong>{attempt.query}</strong><p>{attempt.provider} · {attempt.status} · {attempt.candidate_count} 个候选{attempt.error_code ? ` · ${attempt.error_code}` : ''}</p>{attempt.cache_hit && <p>{attempt.stale ? '过期缓存' : '缓存'}：{dateLabel(attempt.cached_at)}</p>}</div>)}</div></details>}
    </>}
    {!results && <div className="empty-state"><SearchIcon/><h3>{jobId ? '正在读取任务' : '从一个知识点开始'}</h3><p>搜索结果将在这里逐步出现</p><span>页面信息、访问条件与内容覆盖分别标注。</span></div>}
    <div className="principles"><span>真实来源链接</span><span>未知信息如实标注</span><span>跳转原平台学习</span></div>
  </section>;
}
