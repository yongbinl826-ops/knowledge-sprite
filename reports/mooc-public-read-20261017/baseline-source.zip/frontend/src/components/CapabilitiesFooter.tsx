import { dateLabel, externalUrl, statusNames } from '../api';
import type { Capabilities } from '../types';

const metadataNames: Record<string, string> = {
  site_policy_blocked: '当前政策停止自动采集', policy_unreviewed: '自动采集许可范围待确认',
  public_metadata_when_allowed: '逐站检查许可与 robots 后采集', public_metadata_with_explicit_scope: '按部署者已授权范围采集，仍检查 robots',
  disabled: '自动采集已关闭',
};

export function CapabilitiesFooter({ capabilities, onRefresh }: { capabilities: Capabilities | null; onRefresh: () => void }) {
  const render = capabilities?.js_render;
  return <footer className="capabilities-footer"><details><summary><span>搜索服务 {capabilities ? statusNames[capabilities.search.status] || capabilities.search.status : '检查中'}</span><span>查询与排序 {capabilities?.llm.status === 'unconfigured' || capabilities?.llm.status === 'disabled' ? '规则模式' : capabilities ? '按服务端配置' : '检查中'}</span><span>运行模式 {capabilities?.mode === 'live' ? 'Live' : capabilities?.mode || '待确认'}</span><span className="details-affordance">能力详情⌄</span></summary><div className="capabilities-detail"><h3>当前能力</h3><p>当前搜索服务：{capabilities?.search.selected_provider || '未知'}。已配置表示参数齐全，可用表示最近请求成功。</p>{capabilities?.search.providers.map(provider => <p key={provider.name}><strong>{provider.name}</strong> · {statusNames[provider.status] || provider.status} — {provider.message}</p>)}<p>查询扩展与排序：{capabilities?.llm.message || '未知'}</p><p>页面采集：{capabilities?.fetch.message || '未知'}</p><p>在线浏览器采集回退：{capabilities ? capabilities.fetch.browser_fallback ? '已启用' : '已关闭' : '未知'}</p>
    <div className="render-capabilities"><p>受控 JS 补全：{!render ? '未知（服务端未返回）' : !render.enabled || render.status === 'disabled' ? '已关闭' : render.status === 'configured' ? '已配置，动态增益需逐页核对' : '配置尚未就绪'}</p>
      {render && <><p>允许页面来源：{render.allowed_hosts.join('、') || '未配置'} · 允许跨源资产：{render.asset_hosts.join('、') || '未配置'}</p>{!!render.allowed_entries?.length && <p>仅允许这些课程入口：{render.allowed_entries.join('、')}</p>}<p>单次补全上限：{render.max_resources} 个资产 · {render.max_target_requests} 次补充目标请求 · {render.max_doh_requests} 次 DoH · {render.timeout_seconds} 秒。</p><p>{render.message}。</p></>}
    </div><p>点击真实来源链接前往原平台；登录、选课和付费条件以来源页面为准，未知项会明确标注。</p>
    <div className="platform-capabilities">{capabilities?.platforms.map(platform => <section key={platform.id}><h4>{platform.name}</h4><p>发现方式：{platform.discovery === 'search' ? '支持搜索发现，不保证本次有结果' : '当前未确认'}</p><p>自动采集：{metadataNames[platform.metadata] || '状态未知'}</p><p>目录：可选补充，以实际证据为准</p>{platform.policy_basis && <p>{platform.policy_basis}</p>}{platform.policy_section && <p>条款：{platform.policy_section} · 版本 {dateLabel(platform.terms_date)}{platform.effective_at ? ` · 生效 ${dateLabel(platform.effective_at)}` : ''}</p>}{platform.source_url && externalUrl(platform.source_url) && <p><a href={externalUrl(platform.source_url)} target="_blank" rel="noopener noreferrer">查看政策依据</a> · 核对日期 {dateLabel(platform.reviewed_at)}</p>}</section>)}</div>
    {!capabilities?.platforms.length && <p>平台具体采集范围尚未返回；不能据搜索服务状态推定各平台可用。</p>}<button className="text-button" onClick={onRefresh}>重新检查服务状态</button></div></details></footer>;
}
